package com.samco;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.samco.book.model.Book;
import com.samco.book.repository.BookRepository;
import com.samco.user.model.Person;
import com.samco.user.repository.PersonRepository;

@SpringBootApplication
@RestController

public class MultidatabaseApplication {

	@Autowired
	private BookRepository bookRepository;
	@Autowired
	private PersonRepository personRepository;

	@PostMapping("/postperson")
	public String postPerson(@RequestBody Person person) {
		personRepository.save(person);
		return "POSTED SUCCESSFULLY" + person.getId();
	}
	
	@PostMapping("/Postbook")
	public Book postBook(@RequestBody Book book) {
		return bookRepository.save(book);
	}

	@GetMapping("/getPersons")
	public List<Person> getPersons() {
		return personRepository.findAll();
	}

	@GetMapping("/getBooks")
	public List<Book> getBooks() {
		return bookRepository.findAll();
	}

	public static void main(String[] args) {
		SpringApplication.run(MultidatabaseApplication.class, args);
	}

}
